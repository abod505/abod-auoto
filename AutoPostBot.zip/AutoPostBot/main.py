# Bot Devs Radfx2 @R_AFX CH : @radfx2
# Requier Bot Modules 
import pyromod
import asyncio 


# Requier Config
from Config import app


asyncio.run(app.run())


